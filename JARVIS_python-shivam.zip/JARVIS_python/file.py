import antigravity
def main():
    antigravity.fly()
if __name__=='__main__':
    main()